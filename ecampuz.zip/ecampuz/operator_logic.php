<?php
//operasi logic
echo "operrasi logic  ";

	function bagi($angka1, $angka2){
		$jumlah = 0;
		for ($i=$angka2; $i <=$angka1 ; $i+=$angka2) { 
			$jumlah++;
		}
		return $angka1.':'.$angka2.' jumlah '.$jumlah;
	}

	echo bagi(14, 7);
?>